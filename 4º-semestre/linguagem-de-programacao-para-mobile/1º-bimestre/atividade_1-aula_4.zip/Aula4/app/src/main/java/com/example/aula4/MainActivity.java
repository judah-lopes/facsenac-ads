package com.example.aula4;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView texto = findViewById(R.id.textView);
        Button ingles = findViewById(R.id.EN_US);
        Button portugues = findViewById(R.id.PT_BR);

        ingles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                texto.setText("No PEN, no gain");
            }
        });

        portugues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                texto.setText("Sem dor não há ganhos.");
            }
        });
    }
}
