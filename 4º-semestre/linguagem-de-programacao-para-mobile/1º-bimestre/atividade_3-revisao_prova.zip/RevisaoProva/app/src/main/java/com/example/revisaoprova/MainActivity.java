package com.example.revisaoprova;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // declarando attr no contexto da classe, PÕE O PRIVATE AQUI (BOA PRÁTICA)
    private EditText resposta1;
    private EditText resposta2;
    private EditText resposta3;
    private Button enviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resposta1 = findViewById(R.id.input1);
        resposta2 = findViewById(R.id.input2);
        resposta3 = findViewById(R.id.input3);
        enviar = findViewById(R.id.buttonEnviar);

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validaProva();
            }
        });
    }

    private void validaProva() {
        String resposta1Str = resposta1.getText().toString();
        String resposta2Str = resposta2.getText().toString();
        String resposta3Str = resposta3.getText().toString();

        // mudar de tela
        Intent segundaTela = new Intent(MainActivity.this, TelaResultado.class);

        // envia os valores para a outra página
        segundaTela.putExtra("chaveResposta1",resposta1Str);
        segundaTela.putExtra("chaveResposta2",resposta2Str);
        segundaTela.putExtra("chaveResposta3",resposta3Str);
        startActivity(segundaTela);
    }
}