package com.example.revisaoprova;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TelaResultado extends AppCompatActivity {
    private TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_resultado);
        resultado = findViewById(R.id.resultado);

        // recebendo os valores da outra pagina
        String resposta1 = getIntent().getStringExtra("chaveResposta1");
        String resposta2 = getIntent().getStringExtra("chaveResposta2");
        String resposta3 = getIntent().getStringExtra("chaveResposta3");

        int qtdAcertos = calculaQtdAcertos(resposta1, resposta2, resposta3);
        if (qtdAcertos == 3){
            resultado.setText("Parabéns, você tirou 10");
        } else if (qtdAcertos == 2) {
            resultado.setText("Melhore! nota 5");
        } else if (qtdAcertos == 1) {
            resultado.setText("Carai, paizão... nota 3");
        } else {
            resultado.setText("se mata Heriston Davi. nota 0");
        }
    }

    private int calculaQtdAcertos(String resposta1, String resposta2, String resposta3) {
        int qtdAcertos = 0;
        if (resposta1.equalsIgnoreCase("errado")){
            qtdAcertos++;
        }if (resposta2.equalsIgnoreCase("errado")){
            qtdAcertos++;
        }if (resposta3.equalsIgnoreCase("errado")){
            qtdAcertos++;
        }
        return qtdAcertos;
    }
}