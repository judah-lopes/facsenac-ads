package com.example.aula6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    // variável = componente de tela
    EditText nota1;
    EditText nota2;
    Button calcular;
    TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //inicializar as variáveis
        nota1 = findViewById(R.id.inputNota1);
        nota2 = findViewById(R.id.inputNota2);
        calcular = findViewById(R.id.buttonCalcular);
        resultado = findViewById(R.id.resultado);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1. Pegar os valores dos inputs e calcular a média.
                // A fórmula foi corrigida com parênteses e colocada aqui dentro.
                float mediaFinal = ((Float.parseFloat(nota1.getText().toString()) * 4) + (Float.parseFloat(nota2.getText().toString()) * 6)) / 10;

                // 2. Converter o resultado para String e mostrar na tela.
                resultado.setText(String.valueOf(mediaFinal));
            }
        });
    }
}