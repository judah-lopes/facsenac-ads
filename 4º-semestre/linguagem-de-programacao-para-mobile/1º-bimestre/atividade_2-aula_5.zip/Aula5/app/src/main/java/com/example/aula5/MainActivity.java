package com.example.aula5;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText nota1 = findViewById(R.id.nota1);
        EditText nota2 = findViewById(R.id.nota2);
        EditText nota3 = findViewById(R.id.nota3);
        Button calcular = findViewById(R.id.buttonCalcular);
        TextView resultado = findViewById(R.id.resultado);

        calcular.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String nota1Str = nota1.getText().toString();
                String nota2Str = nota2.getText().toString();
                String nota3Str = nota3.getText().toString();
                float nota1Float = Float.parseFloat(nota1Str) * 3;
                float nota2Float = Float.parseFloat(nota2Str) * 3;
                float nota3Float = Float.parseFloat(nota3Str) * 4;

                float notaFinal = (nota1Float + nota2Float * nota3Float) / 10;
                resultado.setText("Essa é a Média Final do aluno:" + notaFinal);
            }
        });

    }
}