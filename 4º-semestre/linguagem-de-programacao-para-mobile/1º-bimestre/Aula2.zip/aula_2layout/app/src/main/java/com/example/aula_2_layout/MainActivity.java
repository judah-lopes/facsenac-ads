package com.example.aula_2_layout;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView titulo = findViewById(R.id.textView);
        TextView subTitulo = findViewById(R.id.textView2);

        titulo.setText("Olá, mundo!");
        subTitulo.setText("Masqueico!");
    }
}
