import { Component } from '@angular/core';

@Component({
  selector: 'app-usuario-list',
  imports: [],
  templateUrl: './usuario-list.html',
  styleUrl: './usuario-list.css'
})
export class UsuarioList {

}
