import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Aplicativo } from './aplicativo.component';

describe('Aplicativo', () => {
  let component: Aplicativo;
  let fixture: ComponentFixture<Aplicativo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Aplicativo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Aplicativo);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
