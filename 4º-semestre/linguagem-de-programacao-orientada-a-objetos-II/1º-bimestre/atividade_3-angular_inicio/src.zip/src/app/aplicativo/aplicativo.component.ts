import { Component } from '@angular/core';
import { RouterLink } from "../../node_modules/@angular/router/router_module.d.d.ts";

@Component({
  selector: 'app-aplicativo',
  imports: [RouterLink],
  templateUrl: './aplicativo.component.html',
  styleUrl: './aplicativo.component.css'
})
export class Aplicativo {

}
