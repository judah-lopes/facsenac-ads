package br.senac.df.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.senac.df.model.Livro;
import br.senac.df.repositorio.LivroRepositorio;

@Service
public class LivroService {
	@Autowired
	LivroRepositorio livroRepositorio;
	
	public List<Livro> getAllLivro() {
		List<Livro> livro = new ArrayList<Livro>();
		livroRepositorio.findAll().forEach(livro1 -> livro.add(livro1));
		return livro;		
	}
	
	public Livro getLivroById(int id) {
		return livroRepositorio.findById(id).get();
	}
	
	public void addLivro(Livro livro) {
		livroRepositorio.save(livro);
	}
	
	public void updateLivro(Livro livro, int id) {
		livroRepositorio.save(livro);
	}
	
	public void deleteLivro(int id) {
		livroRepositorio.deleteById(id);
	}

}
