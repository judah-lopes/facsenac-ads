package br.senac.df.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.senac.df.model.Livro;
import br.senac.df.service.LivroService;

@RestController //recebe
public class LivroController {
	@Autowired
	LivroService livroService;
	
	
	@GetMapping("/livros")
	private List<Livro> getAllLivro(){
		return livroService.getAllLivro();
	}
	
	@GetMapping("/livros/{id}")
	private Livro getLivrosById(@PathVariable("id")int id) {
		return livroService.getLivroById(id);
	}
	
	@PostMapping("/livros")
	private int addLivros(@RequestBody Livro livro) {
		livroService.addLivro(livro);
		return livro.getId();
	}
	
	@PutMapping("/livros/{id}")
	private ResponseEntity<String> updateLivro(@PathVariable int id,@RequestBody Livro livro){
		livroService.updateLivro(livro, id);
		return ResponseEntity.ok("Atualizado com sucesso.");
	}
	
	@DeleteMapping("/livros/{id}")
	private ResponseEntity<String> deleteLivros(@PathVariable int id){
		livroService.deleteLivro(id);
		return ResponseEntity.ok("Excluído com sucesso.");
	}
}