package estrutura;

import java.util.Scanner;

public class JogoDaVelha {

    public void imprimirTabuleiro(String tabuleiro[][]){
        System.out.println("==========IMPRIMIR TABULEIRO=========");
        for (int linha = 0; linha < tabuleiro.length; linha++){
            for (int coluna = 0; coluna < tabuleiro[0].length; coluna++){
                System.out.print(tabuleiro[linha][coluna]+ " ");
            }
            System.out.println();
        } // FIM LINHA
    } // FIM MÉTODO

    public String[][] criarTabuleiro(){
        String tabuleiro[][] = new String[3][3];
        for(int i = 0; i < tabuleiro.length; i++){
            for(int j = 0; j < tabuleiro[0].length; j++){
                tabuleiro[i][j]="-";
            }
        }
        return tabuleiro;
    }
    
    public void jogadas (Scanner input) {
    	String tabuleiro [][] = this.criarTabuleiro();
    	this.imprimirTabuleiro(tabuleiro);
        int contaJogada = 0;
        while (true) {
            contaJogada++;
            System.out.println("Jogador X digite a linha e a coluna:");
            int linha = input.nextInt() - 1;
            int coluna = input.nextInt() - 1;
            tabuleiro[linha][coluna] = "X";
            this.imprimirTabuleiro(tabuleiro);
            if (contaJogada == 9) {
                break;
            }
            System.out.println("Jogador O digite a linha e a coluna:");
            linha = input.nextInt() - 1;
            coluna = input.nextInt() - 1;
            tabuleiro[linha][coluna] = "O";
            this.imprimirTabuleiro(tabuleiro);
        }
        System.out.println("FIM DO JOGO");
    }

    public String [][] jogada(String tabuleiro[][], int linha, int coluna, String jogador, Scanner input) {
        System.out.println("Jogador " + jogador + " digite a linha e a coluna:");
        linha = input.nextInt() - 1;
        coluna = input.nextInt() - 1;
        tabuleiro[linha][coluna] = jogador;
        return tabuleiro;
    }   
}


