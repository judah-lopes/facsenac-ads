    package estrutura;

    import java.util.Scanner;

    public class JogoDaVelhaTest {
        public static void main(String args[]) {
            JogoDaVelha obj = new JogoDaVelha();
            Scanner entrada = new Scanner(System.in);
            obj.jogadas(entrada);
        }
    }
